using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Oclock_Vistas.Pages.Empleado
{
    public class SolicitudesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
