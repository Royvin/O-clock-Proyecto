using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Oclock_Vistas.Pages.Empleado
{
    public class MarcasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
