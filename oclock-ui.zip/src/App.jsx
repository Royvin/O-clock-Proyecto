import { useState } from "react";
import { Home, Clock, FileText, Users, BarChart3, UserCog, Award, Settings } from "lucide-react";

export default function OClockApp() {
  const [view, setView] = useState("inicio");

  const menu = [
    { id: "inicio", label: "Inicio", icon: <Home size={18} /> },
    { id: "asistencia", label: "Asistencia", icon: <Clock size={18} /> },
    { id: "solicitudes", label: "Solicitudes", icon: <FileText size={18} /> },
    { id: "equipo", label: "Mi Equipo", icon: <Users size={18} /> },
    { id: "reportes", label: "Reportes", icon: <BarChart3 size={18} /> },
    { id: "empleados", label: "Empleados", icon: <UserCog size={18} /> },
    { id: "reconocimientos", label: "Reconocimientos", icon: <Award size={18} /> },
    { id: "configuracion", label: "Configuración", icon: <Settings size={18} /> },
  ];

  const renderView = () => {
    switch (view) {
      case "inicio":
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card title="Presentes hoy" value="18" />
            <Card title="Ausentes" value="4" />
            <Card title="Solicitudes pendientes" value="6" />
            <Card title="Llegadas tardías" value="2" />
            <div className="col-span-2 grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
              <QuickAction label="Registrar Asistencia" />
              <QuickAction label="Crear Solicitud" />
              <QuickAction label="Mi Historial" />
              <QuickAction label="Ver Reportes" />
            </div>
          </div>
        );
      case "asistencia":
        return (
          <div className="space-y-4">
            <Section title="Marcaje">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-xl">Registrar Entrada / Salida</button>
              <p className="text-sm text-gray-500 mt-2">Última marca: 08:03 AM</p>
            </Section>
            <Section title="Historial reciente">
              <SimpleTable headers={["Fecha", "Entrada", "Salida", "Estado"]} />
            </Section>
          </div>
        );
      case "solicitudes":
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Section title="Crear Solicitud">
              <FormField label="Tipo" />
              <FormField label="Fecha inicio" />
              <FormField label="Fecha fin" />
              <FormField label="Comentarios" />
              <button className="bg-blue-600 text-white px-4 py-2 rounded-xl mt-2">Crear</button>
            </Section>

            <Section title="Mis Solicitudes">
              <SimpleTable headers={["Tipo", "Fechas", "Estado"]} />
            </Section>
          </div>
        );
      case "equipo":
        return (
          <Section title="Mi Equipo">
            <SimpleTable headers={["Empleado", "Estado", "Llegada", "Solicitudes", "Acciones"]} />
          </Section>
        );
      case "reportes":
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Section title="Tipos de reporte">
              <ul className="space-y-2 text-sm">
                <li>• Asistencia mensual</li>
                <li>• Ranking de puntualidad</li>
                <li>• Ausencias</li>
                <li>• Solicitudes</li>
              </ul>
            </Section>
            <Section title="Exportar">
              <FormField label="Seleccionar reporte" />
              <div className="flex gap-2 mt-2">
                <button className="border px-3 py-1 rounded-lg">PDF</button>
                <button className="border px-3 py-1 rounded-lg">Excel</button>
              </div>
            </Section>
          </div>
        );
      case "empleados":
        return (
          <Section title="Gestión de Empleados">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-xl mb-3">+ Crear Empleado</button>
            <SimpleTable headers={["Nombre", "Rol", "Estado", "Horario", "Acciones"]} />
          </Section>
        );
      case "reconocimientos":
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Section title="Bonos activos">
              <ul className="text-sm space-y-1">
                <li>• Racha 5 días</li>
                <li>• Racha 15 días</li>
                <li>• Puntualidad mensual</li>
              </ul>
            </Section>
            <Section title="Empleados reconocidos">
              <SimpleTable headers={["Empleado", "Bono", "Fecha"]} />
            </Section>
          </div>
        );
      case "configuracion":
        return (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {["Horarios y Políticas", "Días Feriados", "Bonos", "Notificaciones", "Solicitudes", "Seguridad"].map((item) => (
              <div key={item} className="p-4 bg-white shadow rounded-xl border cursor-pointer hover:bg-gray-50">
                {item}
              </div>
            ))}
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 bg-white border-r p-4 space-y-2">
        <h1 className="text-xl font-semibold mb-4">O'clock</h1>
        {menu.map((m) => (
          <div
            key={m.id}
            onClick={() => setView(m.id)}
            className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer hover:bg-gray-100 ${
              view === m.id ? "bg-gray-200" : ""
            }`}
          >
            {m.icon}
            {m.label}
          </div>
        ))}
      </aside>

      <main className="flex-1 p-8 overflow-auto">
        {renderView()}
      </main>
    </div>
  );
}

function Card({ title, value }) {
  return (
    <div className="p-4 bg-white shadow rounded-xl border">
      <p className="text-sm text-gray-500">{title}</p>
      <p className="text-2xl font-bold mt-1">{value}</p>
    </div>
  );
}

function QuickAction({ label }) {
  return (
    <div className="p-6 bg-white shadow rounded-xl border text-center cursor-pointer hover:bg-gray-50">
      {label}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="p-5 bg-white shadow rounded-xl border">
      <h2 className="text-lg font-semibold mb-3">{title}</h2>
      {children}
    </div>
  );
}

function FormField({ label }) {
  return (
    <div className="mb-2">
      <label className="text-sm text-gray-600">{label}</label>
      <input className="w-full mt-1 p-2 border rounded-lg" />
    </div>
  );
}

function SimpleTable({ headers }) {
  return (
    <table className="w-full text-sm mt-2">
      <thead>
        <tr className="border-b bg-gray-50">
          {headers.map((h) => (
            <th key={h} className="p-2 text-left text-gray-600">{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        <tr>
          <td className="p-2 text-gray-400" colSpan={headers.length}>
            (Sin datos)
          </td>
        </tr>
      </tbody>
    </table>
  );
}
